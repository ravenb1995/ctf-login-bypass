# 🔐 Simple CTF Challenge – SQL Injection Login Bypass

This is a beginner-friendly CTF challenge that simulates a login page vulnerable to SQL injection. Great for learning web exploitation basics.

## 💻 Tech Stack
- Python 3 (Flask)
- Docker

## 🚀 How to Run
```bash
docker build -t ctf-login-bypass .
docker run -p 5000:5000 ctf-login-bypass
```

Visit [http://localhost:5000](http://localhost:5000)

## 📁 Files Included
- `login.html` – Frontend login page
- `app.py` – Flask server with vuln logic
- `Dockerfile` – Run everything in a container
- `challenge.md` – Challenge instructions
- `solution.md` – Walkthrough and flag

## 🎯 Flag
`CTF{SQL_BYPASS_SUCCESS}`
